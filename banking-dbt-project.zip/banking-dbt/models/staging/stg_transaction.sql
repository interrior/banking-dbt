{{ config(materialized='view') }}
select transaction_id, account_id, transaction_date, transaction_type, amount, status
from {{ source('banking', 'transactions') }}
