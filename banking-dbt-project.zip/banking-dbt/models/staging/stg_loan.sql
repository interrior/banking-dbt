{{ config(materialized='view') }}
select loan_id, customer_id, loan_type, loan_amount, interest_rate, loan_status, start_date
from {{ source('banking', 'loans') }}
