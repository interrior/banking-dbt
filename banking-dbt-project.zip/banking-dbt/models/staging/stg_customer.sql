{{ config(materialized='view') }}
select customer_id, customer_name, email, phone, status, created_at
from {{ source('banking', 'customers') }}
