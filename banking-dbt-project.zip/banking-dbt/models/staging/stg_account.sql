{{ config(materialized='view') }}
select account_id, customer_id, account_type, balance, status, opened_date
from {{ source('banking', 'accounts') }}
