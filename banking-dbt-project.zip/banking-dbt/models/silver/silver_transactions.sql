{{ config(materialized='table') }}
select t.transaction_id,t.account_id,a.customer_id,t.transaction_date,t.transaction_type,t.amount,t.status
from {{ ref('stg_transaction') }} t left join {{ ref('stg_account') }} a on t.account_id=a.account_id
