{{ config(materialized='table') }}
select c.customer_id,c.customer_name,c.email,a.account_id,a.account_type,a.balance,a.status as account_status
from {{ ref('stg_customer') }} c left join {{ ref('stg_account') }} a on c.customer_id=a.customer_id
