{{ config(materialized='table') }}
select distinct account_id,customer_id,account_type,account_status from {{ ref('silver_customer_account') }} where account_id is not null
