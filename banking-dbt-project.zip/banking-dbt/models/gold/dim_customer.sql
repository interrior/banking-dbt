{{ config(materialized='table') }}
select distinct customer_id,customer_name,email from {{ ref('silver_customer_account') }}
