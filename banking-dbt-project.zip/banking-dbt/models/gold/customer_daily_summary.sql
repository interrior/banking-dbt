{{ config(materialized='table') }}
select customer_id,transaction_date,count(*) transaction_count,sum(amount) total_transaction_amount, sum(case when transaction_type='CREDIT' then amount else 0 end) total_credit, sum(case when transaction_type='DEBIT' then amount else 0 end) total_debit
from {{ ref('silver_transactions') }} group by customer_id,transaction_date
