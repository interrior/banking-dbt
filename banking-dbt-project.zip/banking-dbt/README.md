# Banking dbt Project

Staging, silver and gold dbt models plus a snapshot, macro and seed.

Update the BigQuery source/schema and column names to match your actual source tables before running.
