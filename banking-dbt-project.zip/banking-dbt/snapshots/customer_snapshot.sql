{% snapshot customer_snapshot %}
{{ config(target_schema='snapshots',unique_key='customer_id',strategy='timestamp',updated_at='updated_at') }}
select customer_id,customer_name,email,phone,status,created_at,updated_at from {{ source('banking','customers') }}
{% endsnapshot %}
