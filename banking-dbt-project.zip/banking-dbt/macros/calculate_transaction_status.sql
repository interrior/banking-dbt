{% macro calculate_transaction_status(status) %}
case
 when upper({{ status }}) in ('SUCCESS','COMPLETED','SUCCESSFUL') then 'SUCCESS'
 when upper({{ status }}) in ('FAILED','FAILURE','REJECTED') then 'FAILED'
 when upper({{ status }}) in ('PENDING','PROCESSING') then 'PENDING'
 else 'UNKNOWN'
end
{% endmacro %}
